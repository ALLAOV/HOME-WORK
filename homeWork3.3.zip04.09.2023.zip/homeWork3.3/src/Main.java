import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter first full number: ");
        int num1 = scan.nextInt();

        System.out.println("Enter action: ");
        String action = scan.nextLine();
        action = scan.nextLine();

        System.out.println("Enter second full number: ");
        int num2 = scan.nextInt();

        int result;
        switch (action) {
            case "+":
                result = num1 + num2;
                System.out.println(" total: " + result);
                break;

            case "-":
                result = num1 - num2;
                System.out.println(" total: " + result);
                break;

            case "*":
                result = num1 * num2;
                System.out.println(" total: " + result);
                break;

            case "/":
                
                result = num1 / num2;
                System.out.println("total: " + result);
                break;

        }
    }
}