import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Good day,enter your name : ");
        String name = scan.nextLine();
        System.out.println(name + ", " + "how old are you? ");
        int age = scan.nextInt();
        System.out.println("Please, tell me, what is your weight? ");
        double weight = scan.nextDouble();
        System.out.println("Darling " + name + ", " + "in yours " + age +" age.You are as precious, as " + weight + " kilograms of gold!");
    }
}