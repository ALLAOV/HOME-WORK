public class Main {
    public static void main(String[] args) {
        // exercise 1
        char herLetter = 'G';
        int herNumber = 89;
        byte herByte = 4;
        short herShort = 56;
        float herFloatNum = 4.7333436f;
        double herNum = 4.355453532;
        long herLong = 12121;
        System.out.println(herLetter);
        System.out.println(herNumber);
        System.out.println(herByte);
        System.out.println(herShort);
        System.out.println(herFloatNum);
        System.out.println(herNum);
        System.out.println(herLong);

        // exercise 2
        int num = 237;
        System.out.println(num/100);
        System.out.println(num/70);
        System.out.println(num/30);

        int abc = 850;
        System.out.println(abc/100);
        System.out.println(abc/170);
        System.out.println(abc%850);
    }
}