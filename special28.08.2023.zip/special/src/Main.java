public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, my name is Ala!");
        System.out.println("Hello,");
        System.out.println("my");
        System.out.println("name");
        System.out.println("is");
        System.out.println("Ala");
    }
}