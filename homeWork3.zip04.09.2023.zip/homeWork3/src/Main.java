import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //task number 1
        Random rnd = new Random();
        byte myb = (byte) rnd.nextInt();
        int myi = rnd.nextInt();
        long myl = rnd.nextLong();
        double myd = rnd.nextDouble();
        boolean mybo = rnd.nextBoolean();
        float myf = rnd.nextFloat();
        short mys = (short) rnd.nextInt();
        char mych = (char) rnd.nextInt();
        System.out.println(myb);
        System.out.println(myi);
        System.out.println(myl);
        System.out.println(myd);
        System.out.println(mybo);
        System.out.println(myf);
        System.out.println(mys);
        System.out.println(mych);

        //task number 2

        long l2457 = rnd.nextLong();
        String str = String.valueOf(l2457);
        System.out.println(str);
    }



}